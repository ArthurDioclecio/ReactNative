import React from "react";
import {useRouter} from "expo-router";
import { View } from "react-native";


export default function Characters() {
     const router = useRouter();
     return (
        <View>

        </View>
     );
    }